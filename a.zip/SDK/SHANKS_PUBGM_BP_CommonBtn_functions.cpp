// HMOOD__TG@i_8_f
 

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
 
 
 

void UBP_CommonBtn_C::OnChangeOpenDoorMode(int OpenMode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.OnChangeOpenDoorMode");

	UBP_CommonBtn_C_OnChangeOpenDoorMode_Params params;
	params.OpenMode = OpenMode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UBP_CommonBtn_C::UnRegistShowDoorButton()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.UnRegistShowDoorButton");

	UBP_CommonBtn_C_UnRegistShowDoorButton_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 
 

void UBP_CommonBtn_C::OnShowDoorButton(TEnumAsByte<ECommonBtn> Type, int OpenParam)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.OnShowDoorButton");

	UBP_CommonBtn_C_OnShowDoorButton_Params params;
	params.Type = Type;
	params.OpenParam = OpenParam;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UBP_CommonBtn_C::RegistShowDoorButton()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.RegistShowDoorButton");

	UBP_CommonBtn_C_RegistShowDoorButton_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 
 
 

void UBP_CommonBtn_C::ShowDoorButton(bool Show, bool Open, int OpenMode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.ShowDoorButton");

	UBP_CommonBtn_C_ShowDoorButton_Params params;
	params.Show = Show;
	params.Open = Open;
	params.OpenMode = OpenMode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 

void UBP_CommonBtn_C::GetPlayerController(class ABP_STExtraPlayerController_C** PlayerController)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.GetPlayerController");

	UBP_CommonBtn_C_GetPlayerController_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (PlayerController != nullptr)
		*PlayerController = params.PlayerController;
}


 
 

void UBP_CommonBtn_C::ReceiveBeginPlay()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.ReceiveBeginPlay");

	UBP_CommonBtn_C_ReceiveBeginPlay_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 
 

void UBP_CommonBtn_C::CharacterStatusChanged(bool IsNearDeath, bool IsRescueingOther)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.CharacterStatusChanged");

	UBP_CommonBtn_C_CharacterStatusChanged_Params params;
	params.IsNearDeath = IsNearDeath;
	params.IsRescueingOther = IsRescueingOther;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UBP_CommonBtn_C::PlayerControllerReconnectedDelegate_Event_1()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.PlayerControllerReconnectedDelegate_Event_1");

	UBP_CommonBtn_C_PlayerControllerReconnectedDelegate_Event_1_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 
 

void UBP_CommonBtn_C::UI_Click(bool bSimulateExtraDoor, int OpenParam)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.UI_Click");

	UBP_CommonBtn_C_UI_Click_Params params;
	params.bSimulateExtraDoor = bSimulateExtraDoor;
	params.OpenParam = OpenParam;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UBP_CommonBtn_C::ToogleDoor()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.ToogleDoor");

	UBP_CommonBtn_C_ToogleDoor_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 
 
 

void UBP_CommonBtn_C::BP_ShowDoorBtn(bool* bShow, bool* bOpen, int* doorOpenMode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.BP_ShowDoorBtn");

	UBP_CommonBtn_C_BP_ShowDoorBtn_Params params;
	params.bShow = bShow;
	params.bOpen = bOpen;
	params.doorOpenMode = doorOpenMode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 

void UBP_CommonBtn_C::AutoOpenDoor(bool BoolValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.AutoOpenDoor");

	UBP_CommonBtn_C_AutoOpenDoor_Params params;
	params.BoolValue = BoolValue;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 

void UBP_CommonBtn_C::BP_SimulateUIClick(bool* bExtraDoor)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.BP_SimulateUIClick");

	UBP_CommonBtn_C_BP_SimulateUIClick_Params params;
	params.bExtraDoor = bExtraDoor;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 

void UBP_CommonBtn_C::ExecuteUbergraph_BP_CommonBtn(int EntryPoint)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_CommonBtn.BP_CommonBtn_C.ExecuteUbergraph_BP_CommonBtn");

	UBP_CommonBtn_C_ExecuteUbergraph_BP_CommonBtn_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

